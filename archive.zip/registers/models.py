from django.db import models
from corps.models import Corporation, Party
from django.utils.translation import gettext_lazy as _


class ShareClass(models.Model):
    corp = models.ForeignKey(Corporation, on_delete=models.CASCADE, related_name="share_classes", verbose_name=_("Société"))
    name = models.CharField(_("Nom de la catégorie"), max_length=100)
    description = models.TextField(_("Description"), blank=True)
    par_value = models.DecimalField(max_digits=12, decimal_places=4, null=True, blank=True)
    is_voting = models.BooleanField(_("Droit de vote"), default=False)
    is_redeemable = models.BooleanField(_("Rachetable"), default=False)
    is_retractable = models.BooleanField(_("Rachetable à la demande"), default=False)
    transfer_restrictions = models.TextField(_("Restrictions à l’aliénation"), blank=True)

    class Meta:
        verbose_name = _("Catégorie d’actions")
        verbose_name_plural = _("Catégories d’actions")

class ShareCertificate(models.Model):
    corp = models.ForeignKey(Corporation, on_delete=models.CASCADE, related_name="certificates", verbose_name=_("Société"))
    share_class = models.ForeignKey(ShareClass, verbose_name=_("Classe"), on_delete=models.PROTECT)
    number = models.CharField(_("Numéro du certificat"), max_length=20)
    holder = models.ForeignKey(Party, verbose_name=_("Détenteur"), on_delete=models.PROTECT)
    quantity = models.PositiveIntegerField(verbose_name=_("Quanté"))
    issued_on = models.DateField(verbose_name=_("Date d’émission"))
    cancelled_on = models.DateField(null=True, blank=True, verbose_name=_("Date d’annulation"))
    reason_cancelled = models.CharField(max_length=200, blank=True, verbose_name=_("Raison de l’annulation"))

    class Meta:
        verbose_name = _("Certificat d’actions")
        verbose_name_plural = _("Certificats d’actions")

class ShareIssuance(models.Model):
    corp = models.ForeignKey(Corporation, on_delete=models.CASCADE)
    share_class = models.ForeignKey(ShareClass, on_delete=models.PROTECT, verbose_name=_("Classe"))
    to_holder = models.ForeignKey(Party, on_delete=models.PROTECT, related_name="issuances", verbose_name=_("Bénéficiaire"))
    quantity = models.PositiveIntegerField(verbose_name=_("Quantité"))
    consideration = models.CharField(max_length=255, blank=True, verbose_name=_("Contrepartie"))
    resolution_ref = models.CharField(max_length=255, blank=True, verbose_name=_("Date de la résolution"))
    occurred_on = models.DateField(verbose_name=_("Date d’émission"))

    class Meta:
        verbose_name = _("Émission d’actions")
        verbose_name_plural = _("Émissions d’actions")

class ShareTransfer(models.Model):
    corp = models.ForeignKey(Corporation, on_delete=models.CASCADE)
    share_class = models.ForeignKey(ShareClass, on_delete=models.PROTECT)
    from_holder = models.ForeignKey(Party, on_delete=models.PROTECT, related_name="transfers_out", verbose_name=_("Cédant"))
    to_holder = models.ForeignKey(Party, on_delete=models.PROTECT, related_name="transfers_in", verbose_name=_("Cessionnaire"))
    quantity = models.PositiveIntegerField(verbose_name=_("Quantité"))
    occurred_on = models.DateField(verbose_name=_("Date de transfert"))
    consideration = models.CharField(max_length=255, blank=True, verbose_name=_("Contrepartie"))

    class Meta:
        verbose_name = _("Transfert d’actions")
        verbose_name_plural = _("Transferts d’actions")

class ShareRedemption(models.Model):
    corp = models.ForeignKey(Corporation, on_delete=models.CASCADE)
    share_class = models.ForeignKey(ShareClass, on_delete=models.PROTECT)
    from_holder = models.ForeignKey(Party, on_delete=models.PROTECT, verbose_name=_("Actionnaire racheté"))
    quantity = models.PositiveIntegerField(verbose_name=_("Quantité"))
    occurred_on = models.DateField(verbose_name=_("Date de rachat"))

    class Meta:
        verbose_name = _("Rachat d’actions")
        verbose_name_plural = _("Rachats d’actions")

# Utilitaire: cap table (agrégation ORM)
from django.db.models import Sum

def compute_cap_table(corp: Corporation):
    """Retourne { (holder_id, class_id): qty } en tenant compte émissions, transferts, rachats."""
    result = {}
    # Issuances
    for row in (ShareIssuance.objects
                .filter(corp=corp)
                .values("to_holder", "share_class")
                .annotate(qty=Sum("quantity"))):
        result[(row["to_holder"], row["share_class"])] = result.get((row["to_holder"], row["share_class"]), 0) + row["qty"]
    # Transfers out
    for row in (ShareTransfer.objects
                .filter(corp=corp)
                .values("from_holder", "share_class")
                .annotate(qty=Sum("quantity"))):
        key = (row["from_holder"], row["share_class"])
        result[key] = result.get(key, 0) - row["qty"]
    # Transfers in
    for row in (ShareTransfer.objects
                .filter(corp=corp)
                .values("to_holder", "share_class")
                .annotate(qty=Sum("quantity"))):
        key = (row["to_holder"], row["share_class"])
        result[key] = result.get(key, 0) + row["qty"]
    # Redemptions
    for row in (ShareRedemption.objects
                .filter(corp=corp)
                .values("from_holder", "share_class")
                .annotate(qty=Sum("quantity"))):
        key = (row["from_holder"], row["share_class"])
        result[key] = result.get(key, 0) - row["qty"]
    return result
