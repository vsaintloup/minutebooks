from allauth.socialaccount.providers.base import ProviderAccount
from allauth.socialaccount.providers.oauth2.provider import OAuth2Provider
from allauth.socialaccount.providers.robinhood.views import RobinhoodOAuth2Adapter


class RobinhoodAccount(ProviderAccount):
    def get_avatar_url(self):
        return None


class RobinhoodProvider(OAuth2Provider):
    id = "robinhood"
    name = "Robinhood"
    account_class = RobinhoodAccount
    oauth2_adapter_class = RobinhoodOAuth2Adapter

    def get_default_scope(self):
        return ["read"]

    def extract_uid(self, data):
        return data["id"]

    def extract_common_fields(self, data):
        return dict(username=data.get("username"))


provider_classes = [RobinhoodProvider]
